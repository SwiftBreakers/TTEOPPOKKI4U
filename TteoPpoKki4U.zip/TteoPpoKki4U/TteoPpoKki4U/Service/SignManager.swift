//
//  SignManager.swift
//  TteoPpoKki4U
//
//  Created by Dongik Song on 5/31/24.
//

import Foundation
import FirebaseAuth
import FirebaseDatabase
import FirebaseStorage
import AuthenticationServices

class SignManager {
    
    func saveRealtimeDatabase(appleCredential: ASAuthorizationAppleIDCredential, userName: String) {
        let credential = OAuthProvider.credential(withProviderID: "apple.com",idToken: String(data: appleCredential.identityToken!, encoding: .utf8)!, rawNonce: nil)
        
        Auth.auth().signIn(with: credential) { result, error in
            if let error = error {
                print(error)
            }
            
            let ref = Database.database().reference()
            //ref.child("users").child(userInfo).setValue(<#T##value: Any?##Any?#>)
        }
    }
    
}



//
//  SearchLocation.swift
//  TteoPpoKki4U
//
//  Created by 박준영 on 5/30/24.
//

import Foundation

struct SearchLocation: Codable {
    let name: String
    let latitude: Double
    let longtitude: Double
}

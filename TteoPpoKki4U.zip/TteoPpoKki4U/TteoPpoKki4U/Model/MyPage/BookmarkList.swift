//
//  BookmarkList.swift
//  TteoPpoKki4U
//
//  Created by 박미림 on 6/13/24.
//

import Foundation

struct BookmarkList {
    let title: String
    let imageURL: String
}

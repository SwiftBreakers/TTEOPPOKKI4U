//
//  Review.swift
//  TteoPpoKki4U
//
//  Created by 박미림 on 5/31/24.
//

import Foundation

struct Review {
    let id: Int
    var title: String
    var rating: Float
    var content: String
}

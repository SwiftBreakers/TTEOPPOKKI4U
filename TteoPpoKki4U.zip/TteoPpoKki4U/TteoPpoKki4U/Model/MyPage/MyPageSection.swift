//
//  MyPageSection.swift
//  TteoPpoKki4U
//
//  Created by 박미림 on 5/29/24.
//

import Foundation

struct MyPageSection {
    let title: String
    let options: [MyPageModel]
}


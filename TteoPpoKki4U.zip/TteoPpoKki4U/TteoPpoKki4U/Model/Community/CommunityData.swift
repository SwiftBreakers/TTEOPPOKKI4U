//
//  CommunityData.swift
//  TteoPpoKki4U
//
//  Created by 김건응 on 6/13/24.
//

import Foundation

struct ChatData {
    var name: String
    var text: String
}

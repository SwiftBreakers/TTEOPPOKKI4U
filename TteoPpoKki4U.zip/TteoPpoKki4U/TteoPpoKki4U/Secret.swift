//
//  Secret.swift
//  TteoPpoKki4U
//
//  Created by Dongik Song on 5/29/24.
//

import Foundation

struct Secret {
    
    var kakaoApi = "51ae074db8189189c0ef592e1906d7c8"

}

//
//  Secret.swift
//  TteoPpoKki4U
//
//  Created by Dongik Song on 5/29/24.
//

import Foundation

struct Secret {
    
    var kakaoApi = "51ae074db8189189c0ef592e1906d7c8"

    var kakaoLocalApi = "32b459e18e4f795d25e65e31ec0da140"  // 지도 화면 검색api key
    
    var key = "teamswiftbreakers1!"
}

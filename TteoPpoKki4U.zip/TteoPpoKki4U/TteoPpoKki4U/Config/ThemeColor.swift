//
//  ThemeColor.swift
//  TteoPpoKki4U
//
//  Created by 박미림 on 5/29/24.
//

import UIKit

class ThemeColor {
    static let mainOrange = UIColor(hexString: "FE724C")
    static let mainGreen = UIColor(hexString: "549956")
}


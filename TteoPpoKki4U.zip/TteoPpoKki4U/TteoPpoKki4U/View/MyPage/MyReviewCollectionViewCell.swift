//
//  MyReviewCollectionViewCell.swift
//  TteoPpoKki4U
//
//  Created by 박미림 on 5/30/24.
//

import UIKit

class MyReviewCollectionViewCell: UICollectionViewCell {
    
}
